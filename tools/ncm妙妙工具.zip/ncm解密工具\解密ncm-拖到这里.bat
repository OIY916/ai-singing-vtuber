@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1

rem ---- find a python: RVC_PY env > local Runtime > PATH python ----
set "PY="

if defined RVC_PY if exist "%RVC_PY%" set "PY=%RVC_PY%"

if not defined PY (
    for %%D in ("%~dp0." "%~dp0.." "%~dp0..\..") do (
        if exist "%%~fD\Runtime\python.exe" if not defined PY set "PY=%%~fD\Runtime\python.exe"
    )
)

if not defined PY (
    where python >nul 2>nul && set "PY=python"
)

if not defined PY (
    echo [ERROR] Python not found.
    echo         Set RVC_PY to your RVC Runtime\python.exe, or install Python.
    pause
    exit /b 1
)

echo Using: %PY%
echo.

"%PY%" "%~dp0ncmdump_standalone.py" %*
set RC=%ERRORLEVEL%

echo.
if not "%RC%"=="0" (
    echo [FAILED] see the message above.
    pause
    exit /b %RC%
)

echo [DONE]
pause
